# NEURA MVP (Render free)

Esse é um MVP leve da NEURA — ideal para testar no Render (plano gratuito).

## O que tem
- Frontend Next.js com páginas: Home, Assistant, Agents
- API `/api/assistant` — responde com mock se OPENAI_API_KEY não estiver configurada
- `render.yaml` pronto para deploy no Render

## Deploy no Render (passos)
1. Faça upload dos arquivos deste projeto para o repositório `neura-ai` no seu GitHub.
   - Pelo celular: repositório → Add file → Upload files → escolha todos os arquivos e faça commit.
2. Crie uma conta grátis no Render (https://render.com) e conecte ao GitHub.
3. No Render, clique em **New → Web Service**:
   - Connect to GitHub
   - Select `neura-ai` repository
   - Name: `neura-ai`
   - Environment: Node
   - Branch: `main`
   - Build command: `npm install && npm run build`
   - Start command: `npm run start`
   - Plan: **Free**
4. (Opcional) Configure variável de ambiente `OPENAI_API_KEY` no settings do serviço para obter respostas reais.
5. Clique Deploy e acesse `https://neura-ai.onrender.com`

## Teste local
```bash
npm install
npm run dev
# abra http://localhost:3000
```

## Notas
- MVP sem Redis, DB ou Twilio (apenas para visual e chat básico)
- Depois que validar, fazemos upgrade para funcionalidades completas.
