import fetch from 'node-fetch';
export default async function handler(req,res){
  if(req.method!=='POST') return res.status(405).json({ error: 'Método não permitido' });
  const { message } = req.body || {};
  if(!message) return res.status(400).json({ error: 'Mensagem vazia' });
  const key = process.env.OPENAI_API_KEY;
  if(!key){
    return res.json({ reply: 'Resposta de exemplo (configure OPENAI_API_KEY para respostas reais).' });
  }
  try{
    const resp = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: { 'Content-Type':'application/json', 'Authorization':'Bearer ' + key },
      body: JSON.stringify({
        model: 'gpt-4o-mini',
        messages: [{ role:'system', content:'Você é NEURA Assistente. Responda em Português e seja útil.' }, { role:'user', content: message }],
        max_tokens: 400
      })
    });
    const data = await resp.json();
    const reply = data.choices?.[0]?.message?.content || data.error?.message || 'Sem resposta';
    return res.json({ reply });
  }catch(e){
    console.error(e);
    return res.status(500).json({ error: 'Erro ao chamar OpenAI' });
  }
}
