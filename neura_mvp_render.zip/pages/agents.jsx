import { useEffect, useState } from 'react';
export default function Agents(){
  const [templates, setTemplates] = useState([]);
  useEffect(()=>{ setTemplates([
    { id:'adv', name:'Agente Advocacia', desc:'Responde dúvidas jurídicas comuns' },
    { id:'adm', name:'Agente Administrativo', desc:'Organiza tarefas e agendas' },
    { id:'vendas', name:'Agente Vendas', desc:'Atende clientes e gera propostas' }
  ]) }, []);
  return (
    <div style={{maxWidth:900, margin:'40px auto', fontFamily:'Inter,system-ui'}}>
      <h2>Modelos de Agentes</h2>
      <div style={{display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:12}}>
        {templates.map(t=>(
          <div key={t.id} style={{background:'#fff',padding:12,borderRadius:10,boxShadow:'0 2px 6px rgba(0,0,0,0.06)'}}>
            <h4>{t.name}</h4>
            <p>{t.desc}</p>
            <button style={{padding:8,borderRadius:6,background:'#0f63ff',color:'#fff'}}>Criar (demo)</button>
          </div>
        ))}
      </div>
    </div>
  )
}
