import Link from 'next/link';
export default function Home(){
  return (
    <div style={{fontFamily:'Inter,system-ui',maxWidth:900,margin:'40px auto',textAlign:'center'}}>
      <h1 style={{fontSize:40}}>NEURA — MVP</h1>
      <p>Test drive rápido: assistente de texto simples e interface para criar agentes.</p>
      <div style={{display:'flex',gap:12,justifyContent:'center',marginTop:30}}>
        <Link href="/assistant"><a style={{padding:12,background:'#6b46ff',color:'#fff',borderRadius:8}}>Abrir Assistente</a></Link>
        <Link href="/agents"><a style={{padding:12,background:'#0f63ff',color:'#fff',borderRadius:8}}>Agentes (Templates)</a></Link>
      </div>
      <footer style={{marginTop:40,color:'#999'}}>Versão MVP — Deploy grátis no Render</footer>
    </div>
  )
}
