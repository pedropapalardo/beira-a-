import { useState } from 'react';
export default function Assistant(){
  const [text, setText] = useState('');
  const [messages, setMessages] = useState([]);
  const [loading, setLoading] = useState(false);

  async function send(){
    if(!text) return;
    const userMsg = { from: 'Você', text };
    setMessages(m=>[...m,userMsg]);
    setText('');
    setLoading(true);
    try{
      const res = await fetch('/api/assistant', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ message: userMsg.text }) });
      const j = await res.json();
      const bot = { from: 'NEURA', text: j.reply || 'Sem resposta' };
      setMessages(m=>[...m, bot]);
    }catch(e){
      setMessages(m=>[...m, {from:'NEURA', text: 'Erro: ' + String(e)}]);
    }finally{
      setLoading(false);
    }
  }

  return (
    <div style={{maxWidth:900, margin:'40px auto', fontFamily:'Inter,system-ui'}}>
      <h2>NEURA Assistente (MVP)</h2>
      <div style={{minHeight:300, background:'#f7f7fb', padding:12, borderRadius:8}}>
        {messages.length===0 && <div style={{color:'#666'}}>Nenhuma mensagem ainda. Envie uma pergunta.</div>}
        {messages.map((m,i)=>(
          <div key={i} style={{marginBottom:10, textAlign: m.from==='Você' ? 'right' : 'left'}}>
            <div style={{display:'inline-block', background: m.from==='Você' ? '#d3e5ff' : '#fff', padding:10, borderRadius:8, maxWidth: '80%'}}>
              <strong style={{display:'block', fontSize:12, color:'#333'}}>{m.from}</strong>
              <div style={{marginTop:6}}>{m.text}</div>
            </div>
          </div>
        ))}
      </div>

      <div style={{display:'flex', gap:8, marginTop:12}}>
        <input value={text} onChange={e=>setText(e.target.value)} placeholder="Escreva sua pergunta..." style={{flex:1,padding:10,borderRadius:8,border:'1px solid #ddd'}} />
        <button onClick={send} disabled={loading} style={{padding:'10px 16px',borderRadius:8,background:'#6b46ff',color:'#fff'}}>Enviar</button>
      </div>
      <p style={{marginTop:12,color:'#666'}}>Obs: Para respostas reais, configure OPENAI_API_KEY nas variáveis de ambiente do Render.</p>
    </div>
  )
}
