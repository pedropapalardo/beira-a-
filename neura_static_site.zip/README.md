# NEURA — Static Frontend (Constelação)

Este é o pacote estático da NEURA (Opção A) com fundo animado de constelação.

## Conteúdo
- index.html
- assistant.html
- agents.html
- editor.html
- style.css
- particles.js
- assets/logo.svg

## Deploy no Render (Static Site)
1. Faça upload deste conteúdo (arquivos descompactados) no repositório GitHub ou faça upload direto no Render (Static Site -> Upload folder/ZIP).
2. Se for no Render: em Publish directory escolha `/` (raiz). Build command deixe vazio.
3. Deploy e acesse a URL pública.

